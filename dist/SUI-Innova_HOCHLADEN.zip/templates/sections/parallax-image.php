<?php
/**
 * Parallax Bildstreifen
 *
 * Desktop: background-attachment: fixed.
 * Mobile: JS-basierter Parallax (translateY beim Scrollen).
 */

$imageId    = (int) ($content['image_id'] ?? 0);
$imageUrl   = $imageId ? mediaUrl($imageId) : ($content['image_url'] ?? '');
$height     = $content['height'] ?? 'medium';
$overlayText = $content['overlay_text'] ?? '';

// Alternativtext des Kopfbilds.
//
// Das Bild stammt aus der Mediathek und wird auf mehreren Seiten verwendet,
// sein Alt-Text in der Mediathek beschreibt deshalb nur das Motiv. Hier
// darf jede Seite einen eigenen Text setzen, der den Suchbegriff der Seite
// traegt. Ist keiner gesetzt, bleibt das Bild wie bisher schmueckend und
// damit fuer Screenreader stumm.
$bildAlt = trim((string) ($content['alt'] ?? ''));

$heightClass = match($height) {
    'small'  => 'h-[300px] md:h-[400px] lg:h-[500px]',
    'large'  => 'h-[500px] md:h-[750px] lg:h-[800px]',
    default  => 'h-[400px] md:h-[600px] lg:h-[650px]',
};

if (!$imageUrl) return;
$uniqueId = 'parallax-' . uniqid();

// Der Desktop-Streifen arbeitet mit background-attachment: fixed und kann
// deshalb kein srcset nutzen. Statt des Originals — oft 3000 Pixel breit —
// kommt hier die 1600er-Variante zum Zug. Gibt es die nicht, faellt der
// Aufruf auf das Original zurueck.
$parallaxDesktopUrl = $imageId ? mediaVariantUrl($imageId, 1600) : $imageUrl;
?>

<section class="relative <?= $heightClass ?> overflow-hidden" id="<?= $uniqueId ?>">
    <!-- Bild (20% grösser als Container für Parallax-Bewegung)
         Nur auf Mobile sichtbar, deshalb reicht eine kleine Variante. -->
    <?php if ($imageId): ?>
        <?= responsiveImg($imageId, [
            'alt'   => $bildAlt,
            'sizes' => '100vw',
            'class' => 'absolute inset-0 w-full object-cover pointer-events-none parallax-img',
            'style' => 'height: 130%; top: -15%;',
            'attrs' => ['data-parallax' => ''],
        ]) ?>
    <?php else: ?>
        <img src="<?= e($imageUrl) ?>" alt="<?= e($bildAlt) ?>"
             class="absolute inset-0 w-full object-cover pointer-events-none parallax-img"
             style="height: 130%; top: -15%;"
             loading="lazy" decoding="async">
    <?php endif; ?>

    <!-- Desktop: zusätzlich bg-fixed als Fallback -->
    <div class="absolute inset-0 hidden md:block bg-cover bg-center bg-no-repeat bg-fixed"
         style="background-image: url('<?= e($parallaxDesktopUrl) ?>');">
    </div>
    <!-- Bild auf Desktop verstecken (bg-fixed übernimmt) -->
    <style>
        @media (min-width: 768px) {
            #<?= $uniqueId ?> .parallax-img { display: none; }
        }
    </style>

    <?php $overlayText = trim(strip_tags($overlayText)); ?>
    <?php if ($overlayText): ?>
        <div class="absolute inset-0 bg-black/30"></div>
        <div class="relative z-10 flex items-center justify-center h-full px-6">
            <p class="text-white text-lg md:text-2xl lg:text-3xl font-bold uppercase tracking-wider text-center"
               style="text-shadow: 0 2px 12px rgba(0,0,0,0.4);">
                <?= e($overlayText) ?>
            </p>
        </div>
    <?php endif; ?>
</section>
